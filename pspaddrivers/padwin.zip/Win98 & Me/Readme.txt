Hardware connection
    1) Turn off your computer and then connect the 25pin port of
       the gamepad to LPT of PC.
    2) After the connecting line is connected, you can start to
       install driver.

Installation:
    1) Run "Setup.exe".
    2) Click "Next".
    3) Choose directory. To install to this directory, click "Next".
    4) Select or custom Program Folder and then click "Next".
    5) Start Copying Files. Click "Next".
    6) Finish.

Testing:
    1) Select "Settings"->"Control Panel" from the "START" menu.
    2) Double click the "Game Controllers" icon.
    3) If installation has succeeded, you can find "WE-706 Gamepad"
       in list box and "Status" is OK.